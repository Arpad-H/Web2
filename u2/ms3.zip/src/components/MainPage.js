import {Component} from "react";
import LoginButton from "./LoginButton"
class MainPage extends Component {
    render() {
        return(
            <div id={"LandingPage"}>
               <h1>WE-2 Forum</h1>
                Dies ist ein Forum, welches im Rahmen des Moduls Web Engineering 2 erstellt wurde
            </div>)
    }
}

export default  MainPage