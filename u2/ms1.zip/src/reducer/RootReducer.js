const authenticationActions = require("../actions/AuthenticationActions");
const initialState = {
    user: null,
    loginPending: false,
    showLoginDialog: false,
    error: null,
    accessToken:null
}
function rootReducer(state = initialState,action) {
    console.log("im reducer " + action.type)
    // console.log(action.payload)
    // eslint-disable-next-line default-case
    switch (action.type) {
        case (authenticationActions.SHOW_LOGINDIALOG):{
            return {
                ...state,
                showLoginDialog: true
            }
        }
        case (authenticationActions.HIDE_LOGINDIALOG):{
            return {
                ...state,
                showLoginDialog: false
            }
        }
        case (authenticationActions.AUTHENTICATION_SUCCESS): {
            return {
                ...state,
                showLoginDialog: false,
                loginPending: false,
                user: action.user,
                accessToken: action.accessToken
            }
        }
        case (authenticationActions.AUTHENTICATION_PENDING): {
            return {
                ...state,
                showLoginDialog: false,
                loginPending: true,
                // user: action.user,
                // accessToken: action.accessToken
            }
        }
        case (authenticationActions.AUTHENTICATION_ERROR): {
            console.log(action.error)
            return {
                ...state,
                error: "Authentication Failed",
                pending: false
            }
        }case (authenticationActions.LOGOUT): {
            console.log(action.error)
            return {
                ...state,
                user: initialState.user,
                loginPending: initialState.loginPending,
                showLoginDialog: initialState.showLoginDialog,
                error: initialState.error,
                accessToken:initialState.accessToken
            }
        }
    }
}
export default rootReducer

