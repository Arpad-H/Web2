import './App.css';
import TopMenu from "./components/TopMenu"
import MainPage from "./components/MainPage";
import PersonalPage from "./components/PersonalPage";
import {connect} from "react-redux";
import React, {Component} from "react";


const mapStateToProps = state => {
    return state
}

class App extends Component {

    render() {

        const token = this.props.accessToken

        let workspace
        if (token){
            workspace = <PersonalPage />
        }else {
            workspace = <MainPage />
        }
        console.log(token)
        return (
            <div className="App">
                <TopMenu/>
                {workspace}
            </div>
        );
    }
}

export default connect(mapStateToProps)(App);
