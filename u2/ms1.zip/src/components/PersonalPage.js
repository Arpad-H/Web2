import {Component} from "react";


class PersonalPage extends Component {
    render() {

        return (<>
            <div id={"PrivatePage"}>
            <h1>WE-2 Forum</h1>
            Dies ist die private Seite
            </div>
        </>)

    }
}

export default PersonalPage