

export const GO_TO_PERSONAL_PAGE = "GO_TO_PERSONAL_PAGE"
export const GO_TO_USER_MANAGEMENT_PAGE = "GO_TO_USER_MANAGEMENT_PAGE"

export function getGoToPersonalPageAction() {
    return {
        type: GO_TO_PERSONAL_PAGE
    }
}

export function getGoToUserManagementPageAction() {
    return {
        type: GO_TO_USER_MANAGEMENT_PAGE
    }
}