// import {configureStore} from "@reduxjs/toolkit";
// import  {rootReducer} from "../features/login/loginSlice"
// import thunk from "redux-thunk";
//
// export const store = configureStore({
//     reducer: {
//         login: rootReducer,
//     },
//     middleware: [thunk]
// })